import 'package:vendor/Pages/Chat/local_notification_model.dart';

String imageUploadMessageKey = 'w0daAWDk81';
LocalNotification localNotificationModel = new LocalNotification();
bool isChatNotTapped = false;
