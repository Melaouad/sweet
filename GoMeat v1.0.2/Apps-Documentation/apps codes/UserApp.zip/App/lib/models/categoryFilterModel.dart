

class CatgoryFilter {
  String latest;
  String byname;
  CatgoryFilter();
}
