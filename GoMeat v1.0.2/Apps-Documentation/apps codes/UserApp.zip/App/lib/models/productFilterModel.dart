class ProductFilter {
  String byname;
  int minPrice;
  int maxPrice;
  String stock;
  int minDiscount;
  int maxDiscount;
  int minRating;
  int maxRating;
  int maxPriceValue;
  String keyword;
  ProductFilter();
}
